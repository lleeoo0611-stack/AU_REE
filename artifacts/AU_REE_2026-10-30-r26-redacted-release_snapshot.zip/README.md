# Portable reviewed database snapshot

Rebuild without network or external Python packages:

python reproducibility/build_census_database.py rebuild --snapshot-dir portable_snapshot --output census_review.sqlite
python reproducibility/build_census_database.py verify --snapshot-dir portable_snapshot --database census_review.sqlite

The editable workbook is portable_snapshot/evidence/deliverable/AU_REE_487_pre_MCDA_five_definition_review.xlsx.
Frozen search/extract evidence is under portable_snapshot/evidence/research_20261029/.
The snapshot manifest lists the original acquisition ZIP hashes which are retained in the full local release but not bundled here. All database tables and included evidence are self-contained and verified; replay of original government acquisition requires those original archives. Workpack scripts are supplied for use in the original expanded workpack.

This is a pre-MCDA census review. Candidate relations remain provisional; missing source evidence and incomplete legal rights chains remain HOLD/open. See the accompanying GitHub report for counts and limitations.
